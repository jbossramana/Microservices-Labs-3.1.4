@DrivenAdapter
package demo.hexagon.adapter.persistence.inmemory;

import demo.hexagon.infrastructure.annotation.DrivenAdapter;
