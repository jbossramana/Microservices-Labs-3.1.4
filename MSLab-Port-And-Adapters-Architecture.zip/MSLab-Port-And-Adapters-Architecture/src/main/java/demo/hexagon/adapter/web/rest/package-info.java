@DriverAdapter
package demo.hexagon.adapter.web.rest;

import demo.hexagon.infrastructure.annotation.DriverAdapter;
