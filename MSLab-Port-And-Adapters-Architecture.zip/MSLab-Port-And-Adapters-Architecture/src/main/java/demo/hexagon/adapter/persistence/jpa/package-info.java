@DrivenAdapter
package demo.hexagon.adapter.persistence.jpa;

import demo.hexagon.infrastructure.annotation.DrivenAdapter;
