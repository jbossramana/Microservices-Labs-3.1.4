package demo.hexagon.adapter.web.rest;

public class ApiBasePath {
    public static final String API_V1 = "/api/v1";
}
