package demo.hexagon.application.port;

public interface DeleteUser {
    void deleteByUserName(String userName);
}
