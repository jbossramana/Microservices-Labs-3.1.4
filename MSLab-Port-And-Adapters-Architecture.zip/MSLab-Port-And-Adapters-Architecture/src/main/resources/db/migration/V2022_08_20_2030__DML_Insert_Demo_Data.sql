INSERT INTO "user" (id, user_name, first_name, last_name, age) VALUES (1, 'Mani', 'Mani', 'Gopal', 54);
INSERT INTO "user" (id, user_name, first_name, last_name, age) VALUES (2, 'Ram', 'Adita', 'Ram', 30);
INSERT INTO "user" (id, user_name, first_name, last_name, age) VALUES (3, 'Maharshi', 'Raghav', 'Maharshi', 20);
